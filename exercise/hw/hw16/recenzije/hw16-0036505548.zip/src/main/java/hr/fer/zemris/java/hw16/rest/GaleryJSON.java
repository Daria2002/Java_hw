package hr.fer.zemris.java.hw16.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import com.google.gson.Gson;

import hr.fer.zemris.java.hw16.servlets.GaleryDB;
import hr.fer.zemris.java.hw16.servlets.Picture;

/**
 * This class uses GSON to work with JSON format
 * 
 * @author af
 */
@Path("/slika")
public class GaleryJSON {
	/**
	 * This method returns all tags as list
	 * 
	 * @return
	 */
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getTagsList() {
		Gson gson = new Gson();
		String text = gson.toJson(GaleryDB.getTags());

		return Response.status(Status.OK).entity(text).build();
	}

	/**
	 * This method returns big picture
	 * 
	 * @param path path
	 * @return big picture as json format
	 */

	@Path("/bigPicture/{path}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getBigPicture(@PathParam("path") String path) {

		if (path != null) {
			path = path.trim();
			if (path.isEmpty()) {
				path = null;
			}
		}
		Picture picture = GaleryDB.getBigPicture(path);

		Gson gson = new Gson();
		String jsonText = gson.toJson(picture);
		return Response.status(Status.OK).entity(jsonText).build();

	}

}
